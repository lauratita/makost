
package apk.makost.event;


public interface MenuEvent {
    
    public void menuSeleceted(int index);
    
}
